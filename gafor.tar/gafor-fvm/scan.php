<?php
	ini_set('memory_limit', '64M');
	require('xmlize.inc.php');
	
	$url_host = 'http://username:password@www.flugwetter.de/scripts/getfile.php?src=/gafor2.xml';
	
	$icao = array('x' => 'x-ray', 'm' => 'mike', 'd' => 'delta', 'o' => 'oscar', 'c' => 'charlie');
	
	$file_content = file_get_contents($url_host);
	
	$xml = xmlize($file_content);
	
	$raw = $xml['gafor']['#'];
	
	$ausgabe = $raw['header'][0]['#']['issued_at'][0]['#'];
	$from = $raw['header'][0]['#']['valid_fr'][0]['#'];
	$next = $raw['header'][0]['#']['next_rep'][0]['#'];
	
	$gafor = array();
	
	for ($i=0, $n=count($raw['area']); $i<$n; $i++) {
	
		$id = $raw['area'][$i]['@']['id'];
		$g1 = $raw['area'][$i]['#']['interval'][0]['#']['gaforIndex'][0]['#'];
		$g2 = $raw['area'][$i]['#']['interval'][1]['#']['gaforIndex'][0]['#'];
		$g3 = $raw['area'][$i]['#']['interval'][2]['#']['gaforIndex'][0]['#'];
		
		$gafor[$id] = array($g1, $g2, $g3);
	
	}
	
	$time = gmdate('H', strtotime($from));
	
	$cache_new = md5(print_r($gafor, true));
	$cache_old = file_get_contents('cache.txt');
	

	if ($cache_new != $cache_old) {
		
		file_put_contents('cache.txt', $cache_new);
		
		$keys = array_keys($gafor);
		$img = imagecreatefrompng('comp/canvas.png');
		$bg = imagecolorallocate($img, 255, 255, 255);
		$line = imagecolorallocate($img, 192, 192, 192);
					
		imagefill($img, 0, 0, $bg);
		
		for ($g=0; $g<3; $g++) {
		
			$map = imagecreatetruecolor(451, 640);
			$bg_map = imagecolorallocate($map, 255, 255, 255);
					
			imagefill($map, 0, 0, $bg_map);
			
			$tmp = imagecreatefrompng('comp/bg.png');
			
			imagecopy($map, $tmp, 0, 0, 0, 0, 451, 640);
			
			imagedestroy($tmp);
			
			for ($i=0, $n=count($keys); $i<$n; $i++) {
				
				$tmp = imagecreatefrompng('comp/' . $icao[strtolower(substr($gafor[$keys[$i]][$g], 0, 1))] . '-' . $keys[$i] . '.png');
				imagecopy($map, $tmp, 0, 0, 0, 0, 451, 640);
				imagedestroy($tmp);
				
				$extra = substr($gafor[$keys[$i]][$g], 1, 1);
				
				if ($extra == 1 || $extra == 5 || $extra == 2) {
				
					$tmp = imagecreatefrompng('comp/dark-' . $keys[$i] . '.png');
					imagecopy($map, $tmp, 0, 0, 0, 0, 451, 640);
					if ($extra == 2) {
						imagecopy($map, $tmp, 0, 0, 0, 0, 451, 640);
					}
					imagedestroy($tmp);
				
				}
				
				if ($extra == 6 || $extra == 7 || $extra == 3) {
				
					$tmp = imagecreatefrompng('comp/light-' . $keys[$i] . '.png');
					imagecopy($map, $tmp, 0, 0, 0, 0, 451, 640);
					if ($extra == 6) {
						imagecopy($map, $tmp, 0, 0, 0, 0, 451, 640);
					}
					imagedestroy($tmp);
				
				}
			
			}
			
			$tmp = imagecreatefrompng('comp/airports.png');
			
			imagecopy($map, $tmp, 0, 0, 0, 0, 451, 640);
			
			imagedestroy($tmp);
			
			imagecopy($img, $map, $g*451, 0, 0, 0, 451, 640);
			
			imagedestroy($map);
		
		}
		
		imageline($img, 450, 25, 450, 615, $line);
		imageline($img, 901, 25, 901, 615, $line);
		
		imageline($img, 25, 640, 451-25, 640, $line);
		imageline($img, 451+25, 640, 451*2-25, 640, $line);
		imageline($img, 451*2+25, 640, 451*3-25, 640, $line);
		
		
		$timeout = str_pad($time, 2, '0', STR_PAD_LEFT) . ':00 - ' . str_pad($time + 2, 2, '0', STR_PAD_LEFT) . ':00 UTC';
		$bbox = imageftbbox(10.5, 0, 'font/ArialBold.ttf', $timeout);
		$width = abs($bbox[4] - $bbox[0]);	
		imagefttext ($img, 10.5, 0, round((450-$width)/2), 625, $line, 'font/ArialBold.ttf', $timeout);
		
		$timeout = str_pad($time + 2, 2, '0', STR_PAD_LEFT) . ':00 - ' . str_pad($time + 4, 2, '0', STR_PAD_LEFT) . ':00 UTC';
		$bbox = imageftbbox(10.5, 0, 'font/ArialBold.ttf', $timeout);
		$width = abs($bbox[4] - $bbox[0]);	
		imagefttext ($img, 10.5, 0, round((450-$width)/2)+451, 625, $line, 'font/ArialBold.ttf', $timeout);
		
		$timeout = str_pad($time + 4, 2, '0', STR_PAD_LEFT) . ':00 - ' . str_pad($time + 6, 2, '0', STR_PAD_LEFT) . ':00 UTC';
		$bbox = imageftbbox(10.5, 0, 'font/ArialBold.ttf', $timeout);
		$width = abs($bbox[4] - $bbox[0]);	
		imagefttext ($img, 10.5, 0, round((450-$width)/2)+902, 625, $line, 'font/ArialBold.ttf', $timeout);
		
		
		$created = 'Gafor ausgegeben am ' . gmdate('d.m.Y - H:i', strtotime($ausgabe)) . ' UTC';
		$bbox = imageftbbox(9, 0, 'font/ArialBold.ttf', $created);
		$width = abs($bbox[4] - $bbox[0]);	
		imagefttext ($img, 9, 0, round(451*3-25-$width), 882-25-30, $line, 'font/ArialBold.ttf', $created);
		
		$created = 'Nächstes Gafor am ' . gmdate('d.m.Y - H:i', strtotime($next)) . ' UTC';
		$bbox = imageftbbox(9, 0, 'font/ArialBold.ttf', $created);
		$width = abs($bbox[4] - $bbox[0]);	
		imagefttext ($img, 9, 0, round(451*3-25-$width), 882-25-15, $line, 'font/ArialBold.ttf', $created);
		
		$created = 'Grafik erstellt am ' . gmdate('d.m.Y - H:i') . ' UTC';
		$bbox = imageftbbox(9, 0, 'font/ArialBold.ttf', $created);
		$width = abs($bbox[4] - $bbox[0]);	
		imagefttext ($img, 9, 0, round(451*3-25-$width), 882-25, $line, 'font/ArialBold.ttf', $created);
		
		
		
		$newname = date('Y-m-d-H-i');
		rename('out/big.png', 'out/archive/big-' . $newname . '.png');
		rename('out/medium.png', 'out/archive/medium-' . $newname . '.png');
		rename('out/small.png', 'out/archive/small-' . $newname . '.png');
		
		imagepng($img, 'out/big.png', 9);
		
		$small = imagecreatetruecolor(676, 440);
		$medium = imagecreatetruecolor(1024, 668);
		
		imagecopyresampled($small, $img, 0, 0, 0, 0, 676, 440, 1353, 882);
		imagecopyresampled($medium, $img, 0, 0, 0, 0, 1024, 668, 1353, 882);
		
		imagedestroy($img);
		
		imagepng($small, 'out/small.png', 9);
		imagepng($medium, 'out/medium.png', 9);
		imagedestroy($small);
		imagedestroy($medium);
	
	}

?>
