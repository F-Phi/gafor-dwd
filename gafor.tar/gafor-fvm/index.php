<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
        "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html>
	<head>
		<title>
			Gafor
		</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	</head>
	<body>
		Gafor Bilder:
		
		<a href="big.html">Gro&szlig;</a>
		<a href="medium.html">Mittel</a>
		<a href="small.html">Klein</a>
		<a href="out/archive/">Archiv</a>
		
		<script type="text/javascript">
		var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
		document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
		</script>
		<script type="text/javascript">
		var pageTracker = _gat._getTracker("UA-4036007-5");
		pageTracker._trackPageview();
		</script>
	</body>
</html>
